#include "l.hpp"

int main()
{
    func();

    return 0;
}
