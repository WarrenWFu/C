#include <cstdio>

void func();
