#include "l.hpp"

void func()
{
    printf("from l2\n");
}
