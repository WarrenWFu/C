#include "l.hpp"

void func()
{
    printf("from l1\n");
}
